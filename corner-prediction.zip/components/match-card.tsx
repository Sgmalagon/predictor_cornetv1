import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, ArrowRight } from "lucide-react"
import Link from "next/link"
import type { Match } from "@/lib/types"

// Props tipadas (mejora la legibilidad y mantenibilidad)
interface MatchCardProps {
  match: Match
}

// Componente para mostrar un partido (SRP: solo se encarga de mostrar un partido)
export default function MatchCard({ match }: MatchCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="bg-gradient-to-r from-red-600/10 to-blue-900/10 px-4 py-2 flex justify-between items-center">
        <Badge variant="outline" className="bg-white">
          {match.competition} - J{match.matchday}
        </Badge>
        <div className="flex items-center text-sm text-muted-foreground">
          <Clock className="h-3 w-3 mr-1" />
          {match.time}
        </div>
      </div>

      <CardContent className="p-4">
        <div className="flex flex-col space-y-4">
          <TeamRow team={match.homeTeam} cornerAvg={match.homeCornerAvg} />

          <TeamRow team={match.awayTeam} cornerAvg={match.awayCornerAvg} />
        </div>

        <div className="mt-4 pt-3 border-t flex justify-between items-center">
          <div>
            <div className="text-xs text-muted-foreground">Corners totales (prom.)</div>
            <div className="text-lg font-bold">{match.totalCornerAvg}</div>
          </div>
          <Badge className="bg-blue-900">{match.stadium}</Badge>
        </div>
      </CardContent>

      <CardFooter className="bg-slate-50 px-4 py-3">
        <Link href={`/prediction/${match.id}`} className="w-full">
          <Button className="w-full bg-gradient-to-r from-red-600 to-blue-900 hover:from-red-700 hover:to-blue-950">
            <span>Predecir Corners</span>
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </CardFooter>
    </Card>
  )
}

// Componente para mostrar un equipo en la tarjeta (SRP: solo muestra información de un equipo)
function TeamRow({ team, cornerAvg }: { team: { id: string; name: string; logoUrl?: string }; cornerAvg: number }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center">
        <div className="h-8 w-8 rounded-full overflow-hidden mr-3 bg-slate-100 flex items-center justify-center">
          <img
            src={team.logoUrl || `/team-logos/${team.id}.png`}
            alt={team.name}
            className="h-full w-full object-contain"
            onError={(e) => {
              console.log(`Error loading image for ${team.name}:`, e)
              // Si la imagen falla, usar un placeholder más visible
              ;(e.target as HTMLImageElement).src = `/placeholder.svg?height=32&width=32&query=${team.name} logo`
            }}
          />
        </div>
        <span className="font-medium">{team.name}</span>
      </div>
      <span className="text-sm font-semibold bg-slate-100 px-2 py-1 rounded">{cornerAvg}</span>
    </div>
  )
}
