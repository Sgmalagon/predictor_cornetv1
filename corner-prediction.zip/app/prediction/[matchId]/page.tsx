"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, LineChart, PieChart, ArrowLeft, Bot } from "lucide-react"
import Link from "next/link"
import { useMatch } from "@/lib/hooks/use-match"
import TeamStats from "@/components/team-stats"
import PredictionResult from "@/components/prediction-result"
import BettingHouses from "@/components/betting-houses"
import { Skeleton } from "@/components/ui/skeleton"
import Navbar from "@/components/navbar"

// Página de predicción (SRP: solo maneja la vista de predicción)
export default function PredictionPage({ params }: { params: { matchId: string } }) {
  const [showPrediction, setShowPrediction] = useState(false)
  const { match, loading, error } = useMatch(params.matchId)

  // Manejo de estados de carga y error
  if (loading) {
    return <MatchLoading />
  }

  if (error || !match) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Partido no encontrado</h2>
        <p className="mb-8">El partido que buscas no existe o ya se ha jugado.</p>
        <Link href="/">
          <Button>Volver a la página principal</Button>
        </Link>
      </div>
    )
  }

  // Extraer los IDs de los equipos
  const homeTeamId = match.homeTeam.id
  const awayTeamId = match.awayTeam.id

  // Función para manejar la predicción
  const handlePrediction = () => {
    setShowPrediction(true)
  }

  return (
    <main className="flex min-h-screen flex-col">
      <Navbar />

      <header className="bg-gradient-to-r from-red-600 to-blue-900 py-6">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-white">Predicción de Corners</h1>
              <p className="text-white/80 mt-1">
                {match.homeTeam.name} vs {match.awayTeam.name} | {match.date} {match.time}
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle>Información del Partido</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row justify-between items-center gap-6 py-4">
                <TeamInfo team={match.homeTeam} cornerAvg={match.homeCornerAvg} />

                <div className="flex flex-col items-center">
                  <div className="text-2xl font-bold mb-2">VS</div>
                  <div className="text-sm text-muted-foreground">{match.stadium}</div>
                  <div className="text-sm font-medium mt-2">
                    {match.date} | {match.time}
                  </div>
                </div>

                <TeamInfo team={match.awayTeam} cornerAvg={match.awayCornerAvg} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Predicción</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center h-[calc(100%-4rem)]">
              <div className="text-center mb-4">
                <div className="text-3xl font-bold">{match.totalCornerAvg}</div>
                <div className="text-sm text-muted-foreground">Corners totales (promedio)</div>
              </div>
              <Button
                size="lg"
                className="w-full bg-gradient-to-r from-red-600 to-blue-900 hover:from-red-700 hover:to-blue-950"
                onClick={handlePrediction}
                disabled={showPrediction} // Deshabilitar si ya se está mostrando la predicción
              >
                <Bot className="mr-2 h-4 w-4" /> Predecir con ChatGPT
              </Button>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="stats" className="mb-8">
          <TabsList className="grid w-full grid-cols-4 mb-4">
            <TabsTrigger value="stats" className="flex items-center gap-2">
              <BarChart className="h-4 w-4" />
              <span>Estadísticas</span>
            </TabsTrigger>
            <TabsTrigger value="home" className="flex items-center gap-2">
              <LineChart className="h-4 w-4" />
              <span>{match.homeTeam.name}</span>
            </TabsTrigger>
            <TabsTrigger value="away" className="flex items-center gap-2">
              <PieChart className="h-4 w-4" />
              <span>{match.awayTeam.name}</span>
            </TabsTrigger>
            <TabsTrigger value="betting" className="flex items-center gap-2">
              <span>💰</span>
              <span>Apuestas</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stats">
            <Card>
              <CardHeader>
                <CardTitle>Comparativa de Estadísticas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <StatComparison
                    title="Corners a Favor"
                    homeValue={match.homeCornerAvg}
                    awayValue={match.awayCornerAvg}
                    homeName={match.homeTeam.name}
                    awayName={match.awayTeam.name}
                  />

                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Corners Totales</h4>
                    <div className="flex flex-col items-center">
                      <div className="text-3xl font-bold">{match.totalCornerAvg}</div>
                      <div className="text-sm text-muted-foreground">promedio por partido</div>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Probabilidad</h4>
                    <div className="flex flex-col items-center">
                      <div className="text-3xl font-bold">76%</div>
                      <div className="text-sm text-muted-foreground">precisión histórica</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="home">
            <TeamStats team={homeTeamId} />
          </TabsContent>

          <TabsContent value="away">
            <TeamStats team={awayTeamId} />
          </TabsContent>

          <TabsContent value="betting">
            <BettingHouses
              matchId={match.id}
              homeTeam={match.homeTeam.name}
              awayTeam={match.awayTeam.name}
              predictedCorners={match.totalCornerAvg}
            />
          </TabsContent>
        </Tabs>

        {showPrediction && (
          <PredictionResult
            homeTeam={match.homeTeam}
            awayTeam={match.awayTeam}
            onClose={() => setShowPrediction(false)}
          />
        )}

        {/* Sección de casas de apuestas destacadas */}
        <div className="mt-8 border-t pt-8">
          <h3 className="text-xl font-bold mb-4">Casas de Apuestas Destacadas</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a
              href={`https://www.wplay.co/apuestas-deportivas/futbol/espana-laliga?utm_source=corner_predictor&utm_medium=referral&utm_campaign=match_${match.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Button variant="outline" className="w-full justify-start h-auto py-3">
                <img src="/betting-houses/wplay.png" alt="Wplay" className="mr-2 h-6 w-6 object-contain" />
                <div className="flex flex-col items-start">
                  <span className="font-medium">Wplay</span>
                  <span className="text-xs text-muted-foreground">Bono de bienvenida</span>
                </div>
              </Button>
            </a>
            <a
              href={`https://betplay.com.co/apuestas-deportivas/futbol/espana?utm_source=corner_predictor&utm_medium=referral&utm_campaign=match_${match.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Button variant="outline" className="w-full justify-start h-auto py-3">
                <img src="/betting-houses/betplay.png" alt="BetPlay" className="mr-2 h-6 w-6 object-contain" />
                <div className="flex flex-col items-start">
                  <span className="font-medium">BetPlay</span>
                  <span className="text-xs text-muted-foreground">Apuesta sin riesgo</span>
                </div>
              </Button>
            </a>
            <a
              href={`https://www.codere.co/deportes/#/LaLiga?utm_source=corner_predictor&utm_medium=referral&utm_campaign=match_${match.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Button variant="outline" className="w-full justify-start h-auto py-3">
                <img src="/betting-houses/codere.png" alt="Codere" className="mr-2 h-6 w-6 object-contain" />
                <div className="flex flex-col items-start">
                  <span className="font-medium">Codere</span>
                  <span className="text-xs text-muted-foreground">Mejores cuotas</span>
                </div>
              </Button>
            </a>
            <a
              href={`https://www.rushbet.co/deportes/futbol/espana-laliga?utm_source=corner_predictor&utm_medium=referral&utm_campaign=match_${match.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Button variant="outline" className="w-full justify-start h-auto py-3">
                <img src="/betting-houses/rushbet.png" alt="Rushbet" className="mr-2 h-6 w-6 object-contain" />
                <div className="flex flex-col items-start">
                  <span className="font-medium">Rushbet</span>
                  <span className="text-xs text-muted-foreground">Apuestas en vivo</span>
                </div>
              </Button>
            </a>
          </div>
          <div className="mt-2 text-xs text-muted-foreground text-center">
            <span className="bg-red-100 text-red-600 px-1 py-0.5 rounded mr-1">+18</span>
            Juega con responsabilidad. Las apuestas deportivas son para mayores de edad.
          </div>
        </div>
      </div>
    </main>
  )
}

// Componente para mostrar información de un equipo (SRP: solo muestra información de un equipo)
function TeamInfo({ team, cornerAvg }: { team: { id: string; name: string; logoUrl?: string }; cornerAvg: number }) {
  return (
    <div className="flex flex-col items-center">
      <div className="h-20 w-20 rounded-full overflow-hidden mb-3 bg-slate-100 flex items-center justify-center">
        <img
          src={team.logoUrl || `/team-logos/${team.id}.png`}
          alt={team.name}
          className="h-full w-full object-contain"
          onError={(e) => {
            console.log(`Error loading image for ${team.name}:`, e)
            // Si la imagen falla, usar un placeholder más visible
            ;(e.target as HTMLImageElement).src = `/placeholder.svg?height=80&width=80&query=${team.name} logo`
          }}
        />
      </div>
      <h3 className="text-lg font-bold">{team.name}</h3>
      <p className="text-sm text-muted-foreground">Corners: {cornerAvg} (prom.)</p>
    </div>
  )
}

// Componente para mostrar una comparación de estadísticas (SRP: solo muestra una comparación)
function StatComparison({
  title,
  homeValue,
  awayValue,
  homeName,
  awayName,
}: {
  title: string
  homeValue: number
  awayValue: number
  homeName: string
  awayName: string
}) {
  const total = homeValue + awayValue
  const homePercentage = (homeValue / total) * 100

  return (
    <div className="bg-slate-50 p-4 rounded-lg">
      <h4 className="font-medium mb-2">{title}</h4>
      <div className="flex justify-between items-center">
        <div className="text-lg font-bold">{homeValue}</div>
        <div className="h-2 flex-1 mx-4 bg-slate-200 rounded-full overflow-hidden">
          <div className="h-full bg-red-600" style={{ width: `${homePercentage}%` }}></div>
        </div>
        <div className="text-lg font-bold">{awayValue}</div>
      </div>
      <div className="flex justify-between text-xs text-muted-foreground mt-1">
        <div>{homeName}</div>
        <div>{awayName}</div>
      </div>
    </div>
  )
}

// Componente para mostrar el estado de carga (SRP: solo muestra el estado de carga)
function MatchLoading() {
  return (
    <main className="flex min-h-screen flex-col">
      <Navbar />

      <header className="bg-gradient-to-r from-red-600 to-blue-900 py-6">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <Skeleton className="h-8 w-64 bg-white/20" />
              <Skeleton className="h-4 w-48 bg-white/20 mt-1" />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row justify-between items-center gap-6 py-4">
                <Skeleton className="h-32 w-32 rounded-full" />
                <div className="flex flex-col items-center gap-2">
                  <Skeleton className="h-6 w-12" />
                  <Skeleton className="h-4 w-24" />
                </div>
                <Skeleton className="h-32 w-32 rounded-full" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center gap-4">
                <Skeleton className="h-16 w-16 rounded-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="stats" className="mb-8">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <Skeleton className="h-10 w-full" />
          </TabsList>

          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Skeleton className="h-32 w-full" />
              </div>
            </CardContent>
          </Card>
        </Tabs>
      </div>
    </main>
  )
}
