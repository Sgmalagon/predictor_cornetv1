import type { CornerAnalysis } from "../types"

// Datos de análisis de corners para la jornada 38
const cornerAnalysisData: Record<number, CornerAnalysis> = {
  38: {
    matchday: 38,
    averageCorners: 10.37,
    analysisDate: "20/05/2025",
    matches: [
      {
        matchId: "j38_athletic_barcelona",
        homeTeam: { id: "athletic-club", name: "Athletic Club" },
        awayTeam: { id: "barcelona", name: "FC Barcelona" },
        prediction: {
          homeCorners: 5.7,
          awayCorners: 7.1,
          totalCorners: 12.8,
          homeFirstHalf: 2.8,
          homeSecondHalf: 2.9,
          awayFirstHalf: 3.5,
          awaySecondHalf: 3.6,
          accuracyPercentage: 85,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_betis_valencia",
        homeTeam: { id: "real-betis", name: "Real Betis" },
        awayTeam: { id: "valencia-cf", name: "Valencia CF" },
        prediction: {
          homeCorners: 5.7,
          awayCorners: 5.0,
          totalCorners: 10.7,
          homeFirstHalf: 2.7,
          homeSecondHalf: 3.0,
          awayFirstHalf: 2.2,
          awaySecondHalf: 2.8,
          accuracyPercentage: 80,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_madrid_sociedad",
        homeTeam: { id: "real-madrid", name: "Real Madrid" },
        awayTeam: { id: "real-sociedad", name: "Real Sociedad" },
        prediction: {
          homeCorners: 5.8,
          awayCorners: 5.3,
          totalCorners: 11.1,
          homeFirstHalf: 3.0,
          homeSecondHalf: 2.8,
          awayFirstHalf: 2.5,
          awaySecondHalf: 2.8,
          accuracyPercentage: 82,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_alaves_osasuna",
        homeTeam: { id: "alaves", name: "Deportivo Alavés" },
        awayTeam: { id: "osasuna", name: "CA Osasuna" },
        prediction: {
          homeCorners: 4.9,
          awayCorners: 5.4,
          totalCorners: 10.3,
          homeFirstHalf: 2.3,
          homeSecondHalf: 2.6,
          awayFirstHalf: 2.7,
          awaySecondHalf: 2.7,
          accuracyPercentage: 78,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_leganes_valladolid",
        homeTeam: { id: "leganes", name: "CD Leganés" },
        awayTeam: { id: "valladolid", name: "Real Valladolid" },
        prediction: {
          homeCorners: 5.4,
          awayCorners: 4.5,
          totalCorners: 9.9,
          homeFirstHalf: 2.5,
          homeSecondHalf: 2.9,
          awayFirstHalf: 2.0,
          awaySecondHalf: 2.5,
          accuracyPercentage: 75,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_espanyol_laspalmas",
        homeTeam: { id: "espanyol", name: "RCD Espanyol" },
        awayTeam: { id: "las-palmas", name: "UD Las Palmas" },
        prediction: {
          homeCorners: 4.9,
          awayCorners: 5.2,
          totalCorners: 10.1,
          homeFirstHalf: 2.4,
          homeSecondHalf: 2.5,
          awayFirstHalf: 2.3,
          awaySecondHalf: 2.9,
          accuracyPercentage: 76,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_girona_atletico",
        homeTeam: { id: "girona-fc", name: "Girona FC" },
        awayTeam: { id: "atletico", name: "Atlético de Madrid" },
        prediction: {
          homeCorners: 4.7,
          awayCorners: 4.4,
          totalCorners: 9.1,
          homeFirstHalf: 2.2,
          homeSecondHalf: 2.5,
          awayFirstHalf: 2.0,
          awaySecondHalf: 2.4,
          accuracyPercentage: 74,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_getafe_celta",
        homeTeam: { id: "getafe", name: "Getafe CF" },
        awayTeam: { id: "celta", name: "RC Celta de Vigo" },
        prediction: {
          homeCorners: 4.9,
          awayCorners: 4.4,
          totalCorners: 9.3,
          homeFirstHalf: 2.3,
          homeSecondHalf: 2.6,
          awayFirstHalf: 2.1,
          awaySecondHalf: 2.3,
          accuracyPercentage: 77,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_rayo_mallorca",
        homeTeam: { id: "rayo", name: "Rayo Vallecano" },
        awayTeam: { id: "mallorca", name: "RCD Mallorca" },
        prediction: {
          homeCorners: 5.1,
          awayCorners: 5.2,
          totalCorners: 10.3,
          homeFirstHalf: 2.6,
          homeSecondHalf: 2.5,
          awayFirstHalf: 2.4,
          awaySecondHalf: 2.8,
          accuracyPercentage: 79,
        },
        date: "25/05/2025",
      },
      {
        matchId: "j38_villarreal_sevilla",
        homeTeam: { id: "villarreal", name: "Villarreal CF" },
        awayTeam: { id: "sevilla", name: "Sevilla FC" },
        prediction: {
          homeCorners: 5.2,
          awayCorners: 4.9,
          totalCorners: 10.1,
          homeFirstHalf: 2.5,
          homeSecondHalf: 2.7,
          awayFirstHalf: 2.3,
          awaySecondHalf: 2.6,
          accuracyPercentage: 80,
        },
        date: "25/05/2025",
      },
    ],
    recommendations: [
      {
        type: "Más de 9.5 corners",
        description: "Favorable para 7 de los 10 partidos",
        confidence: "ALTA",
        matches: [
          "Athletic Club vs FC Barcelona",
          "Real Madrid vs Real Sociedad",
          "Real Betis vs Valencia CF",
          "Deportivo Alavés vs CA Osasuna",
          "Rayo Vallecano vs RCD Mallorca",
          "RCD Espanyol vs UD Las Palmas",
          "Villarreal CF vs Sevilla FC",
        ],
      },
      {
        type: "Ambos equipos más de 4 corners",
        description: "Selectiva para 5 partidos",
        confidence: "MEDIA-ALTA",
        matches: [
          "Athletic Club vs FC Barcelona",
          "Real Betis vs Valencia CF",
          "Real Madrid vs Real Sociedad",
          "Deportivo Alavés vs CA Osasuna",
          "Rayo Vallecano vs RCD Mallorca",
        ],
      },
      {
        type: "Más corners en el segundo tiempo",
        description: "Favorable para la mayoría de partidos",
        confidence: "MEDIA",
        matches: [
          "Athletic Club vs FC Barcelona",
          "Real Betis vs Valencia CF",
          "RCD Espanyol vs UD Las Palmas",
          "Rayo Vallecano vs RCD Mallorca",
        ],
      },
      {
        type: "Combinada de alto valor",
        description: "Athletic-Barcelona +10.5 corners + Real Madrid-Real Sociedad +10.5 corners",
        confidence: "ALTA (70%)",
        matches: ["Athletic Club vs FC Barcelona", "Real Madrid vs Real Sociedad"],
      },
      {
        type: "Combinada conservadora",
        description:
          "Athletic-Barcelona +9.5 corners + Real Madrid-Real Sociedad +9.5 corners + Real Betis-Valencia +9.5 corners",
        confidence: "ALTA (65%)",
        matches: ["Athletic Club vs FC Barcelona", "Real Madrid vs Real Sociedad", "Real Betis vs Valencia CF"],
      },
    ],
  },
}

export class CornerAnalysisRepositoryImpl {
  // Método para obtener análisis de corners por jornada
  async getCornerAnalysisByMatchday(matchday: number): Promise<CornerAnalysis | null> {
    return cornerAnalysisData[matchday] || null
  }
}

// Singleton para acceder al repositorio
export const cornerAnalysisRepository = new CornerAnalysisRepositoryImpl()
