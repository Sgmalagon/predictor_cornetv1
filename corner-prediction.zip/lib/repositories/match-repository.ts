import type { Match, RecentMatch, CornerAnalysis } from "../types"
import { MatchStatus } from "../types"
import { cornerAnalysisRepository } from "./corner-analysis-repository"

// Datos de partidos actualizados con los partidos reales de LaLiga
const matches: Match[] = [
  // Miércoles 14 de mayo de 2025
  {
    id: "match_14_1",
    competition: "LaLiga",
    date: "14/05/2025",
    time: "21:00",
    homeTeam: { id: "real-madrid", name: "Real Madrid" },
    awayTeam: { id: "mallorca", name: "Mallorca" },
    homeCornerAvg: 5.8,
    awayCornerAvg: 4.1,
    totalCornerAvg: 8.2,
    stadium: "Santiago Bernabéu",
    status: MatchStatus.UPCOMING,
    matchday: 35,
    result: "0-1", // Resultado final (si ya se jugó)
  },
  {
    id: "match_14_2",
    competition: "LaLiga",
    date: "14/05/2025",
    time: "19:00",
    homeTeam: { id: "alaves", name: "Alavés" },
    awayTeam: { id: "valencia-cf", name: "Valencia" },
    homeCornerAvg: 4.5,
    awayCornerAvg: 4.2,
    totalCornerAvg: 7.8,
    stadium: "Mendizorroza",
    status: MatchStatus.UPCOMING,
    matchday: 35,
    result: "1-0", // Resultado final (si ya se jugó)
  },
  {
    id: "match_14_3",
    competition: "LaLiga",
    date: "14/05/2025",
    time: "17:00",
    homeTeam: { id: "villarreal", name: "Villarreal" },
    awayTeam: { id: "leganes", name: "Leganés" },
    homeCornerAvg: 5.1,
    awayCornerAvg: 3.8,
    totalCornerAvg: 7.6,
    stadium: "La Cerámica",
    status: MatchStatus.UPCOMING,
    matchday: 35,
    result: "3-0", // Resultado final (si ya se jugó)
  },

  // Jueves 15 de mayo de 2025
  {
    id: "match_15_1",
    competition: "LaLiga",
    date: "15/05/2025",
    time: "15:30", // 3:30 p.m. hora de Colombia
    homeTeam: { id: "espanyol", name: "Espanyol" },
    awayTeam: { id: "barcelona", name: "Barcelona" },
    homeCornerAvg: 3.9,
    awayCornerAvg: 6.2,
    totalCornerAvg: 8.4,
    stadium: "RCDE Stadium",
    status: MatchStatus.UPCOMING,
    matchday: 35,
  },
  {
    id: "match_15_2",
    competition: "LaLiga",
    date: "15/05/2025",
    time: "19:00",
    homeTeam: { id: "osasuna", name: "Osasuna" },
    awayTeam: { id: "atletico", name: "Atlético de Madrid" },
    homeCornerAvg: 4.6,
    awayCornerAvg: 4.9,
    totalCornerAvg: 7.9,
    stadium: "El Sadar",
    status: MatchStatus.UPCOMING,
    matchday: 35,
  },
  {
    id: "match_15_3",
    competition: "LaLiga",
    date: "15/05/2025",
    time: "21:00",
    homeTeam: { id: "rayo", name: "Rayo Vallecano" },
    awayTeam: { id: "real-betis", name: "Real Betis" },
    homeCornerAvg: 4.2,
    awayCornerAvg: 5.7,
    totalCornerAvg: 8.1,
    stadium: "Vallecas",
    status: MatchStatus.UPCOMING,
    matchday: 35,
  },
  {
    id: "match_15_4",
    competition: "LaLiga",
    date: "15/05/2025",
    time: "21:00",
    homeTeam: { id: "getafe", name: "Getafe" },
    awayTeam: { id: "athletic-club", name: "Athletic Club" },
    homeCornerAvg: 4.3,
    awayCornerAvg: 4.7,
    totalCornerAvg: 7.5,
    stadium: "Coliseum",
    status: MatchStatus.UPCOMING,
    matchday: 35,
  },

  // Partidos de la jornada 38 (con datos de predicción de corners)
  {
    id: "j38_athletic_barcelona",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "athletic-club", name: "Athletic Club" },
    awayTeam: { id: "barcelona", name: "FC Barcelona" },
    homeCornerAvg: 5.7,
    awayCornerAvg: 7.1,
    totalCornerAvg: 12.8,
    stadium: "San Mamés",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_betis_valencia",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "real-betis", name: "Real Betis" },
    awayTeam: { id: "valencia-cf", name: "Valencia CF" },
    homeCornerAvg: 5.7,
    awayCornerAvg: 5.0,
    totalCornerAvg: 10.7,
    stadium: "Benito Villamarín",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_madrid_sociedad",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "real-madrid", name: "Real Madrid" },
    awayTeam: { id: "real-sociedad", name: "Real Sociedad" },
    homeCornerAvg: 5.8,
    awayCornerAvg: 5.3,
    totalCornerAvg: 11.1,
    stadium: "Santiago Bernabéu",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_alaves_osasuna",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "alaves", name: "Deportivo Alavés" },
    awayTeam: { id: "osasuna", name: "CA Osasuna" },
    homeCornerAvg: 4.9,
    awayCornerAvg: 5.4,
    totalCornerAvg: 10.3,
    stadium: "Mendizorroza",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_leganes_valladolid",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "leganes", name: "CD Leganés" },
    awayTeam: { id: "valladolid", name: "Real Valladolid" },
    homeCornerAvg: 5.4,
    awayCornerAvg: 4.5,
    totalCornerAvg: 9.9,
    stadium: "Butarque",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_espanyol_laspalmas",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "espanyol", name: "RCD Espanyol" },
    awayTeam: { id: "las-palmas", name: "UD Las Palmas" },
    homeCornerAvg: 4.9,
    awayCornerAvg: 5.2,
    totalCornerAvg: 10.1,
    stadium: "RCDE Stadium",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_girona_atletico",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "girona-fc", name: "Girona FC" },
    awayTeam: { id: "atletico", name: "Atlético de Madrid" },
    homeCornerAvg: 4.7,
    awayCornerAvg: 4.4,
    totalCornerAvg: 9.1,
    stadium: "Montilivi",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_getafe_celta",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "getafe", name: "Getafe CF" },
    awayTeam: { id: "celta", name: "RC Celta de Vigo" },
    homeCornerAvg: 4.9,
    awayCornerAvg: 4.4,
    totalCornerAvg: 9.3,
    stadium: "Coliseum",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_rayo_mallorca",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "rayo", name: "Rayo Vallecano" },
    awayTeam: { id: "mallorca", name: "RCD Mallorca" },
    homeCornerAvg: 5.1,
    awayCornerAvg: 5.2,
    totalCornerAvg: 10.3,
    stadium: "Vallecas",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
  {
    id: "j38_villarreal_sevilla",
    competition: "LaLiga",
    date: "25/05/2025",
    time: "18:30",
    homeTeam: { id: "villarreal", name: "Villarreal CF" },
    awayTeam: { id: "sevilla", name: "Sevilla FC" },
    homeCornerAvg: 5.2,
    awayCornerAvg: 4.9,
    totalCornerAvg: 10.1,
    stadium: "La Cerámica",
    status: MatchStatus.UPCOMING,
    matchday: 38,
  },
]

// Datos de partidos recientes (simulados)
const recentMatchesData: Record<string, RecentMatch[]> = {
  barcelona: [
    {
      match: {
        id: "past1",
        competition: "LaLiga",
        date: "07/05/2025",
        time: "21:00",
        homeTeam: { id: "barcelona", name: "Barcelona" },
        awayTeam: { id: "atletico", name: "Atlético de Madrid" },
        homeCornerAvg: 6.2,
        awayCornerAvg: 4.9,
        totalCornerAvg: 9.5,
        stadium: "Camp Nou",
        status: MatchStatus.FINISHED,
        matchday: 34,
      },
      result: {
        homeGoals: 2,
        awayGoals: 1,
        homeCorners: 7,
        awayCorners: 4,
      },
      isHome: true,
    },
    // Más partidos recientes...
  ],
  // Más equipos...
}

export class MatchRepositoryImpl {
  // Método para obtener partidos próximos por fecha
  async getUpcomingMatches(date: Date): Promise<Match[]> {
    console.log("Repository getting matches for date:", date)

    // Convertir la fecha a formato string para comparar (DD/MM/YYYY)
    const dateStr = date
      .toLocaleDateString("es-ES", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      })
      .replace(/\//g, "/")

    // Para depuración
    console.log("Looking for matches on date:", dateStr)
    console.log(
      "Available matches:",
      matches.map((m) => ({ id: m.id, date: m.date })),
    )

    // Filtrar partidos por fecha
    const matchesByDate = matches.filter((match) => {
      return match.date === dateStr && match.status === MatchStatus.UPCOMING
    })

    console.log("Matches found for date:", matchesByDate.length)

    // Si no hay partidos para esa fecha exacta, devolver partidos de la jornada más cercana
    if (matchesByDate.length === 0) {
      // Devolver algunos partidos por defecto para que siempre haya contenido
      return matches.filter((match) => match.status === MatchStatus.UPCOMING).slice(0, 3)
    }

    return matchesByDate
  }

  // Método para obtener un partido por su ID
  async getMatchById(id: string): Promise<Match | null> {
    const match = matches.find((m) => m.id === id)
    return match || null
  }

  // Método para obtener los últimos partidos de un equipo
  async getLastMatches(teamId: string, count = 5): Promise<RecentMatch[]> {
    const teamMatches = recentMatchesData[teamId] || []
    return teamMatches.slice(0, count)
  }

  // Método para obtener todos los partidos restantes de la temporada
  async getAllRemainingMatches(): Promise<Match[]> {
    // Obtener la fecha actual
    const today = new Date()
    const todayStr = today
      .toLocaleDateString("es-ES", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      })
      .replace(/\//g, "/")

    // Filtrar partidos que son de hoy o posteriores
    return matches
      .filter((match) => {
        // Convertir la fecha del partido a un objeto Date para comparar
        const [day, month, year] = match.date.split("/").map(Number)
        const matchDate = new Date(year, month - 1, day)

        // Convertir la fecha actual a un objeto Date sin la hora
        const todayDate = new Date(today.getFullYear(), today.getMonth(), today.getDate())

        // Devolver true si el partido es de hoy o posterior
        return matchDate >= todayDate && match.status === MatchStatus.UPCOMING
      })
      .sort((a, b) => {
        // Ordenar primero por fecha
        const [dayA, monthA, yearA] = a.date.split("/").map(Number)
        const [dayB, monthB, yearB] = b.date.split("/").map(Number)

        const dateA = new Date(yearA, monthA - 1, dayA)
        const dateB = new Date(yearB, monthB - 1, dayB)

        if (dateA.getTime() !== dateB.getTime()) {
          return dateA.getTime() - dateB.getTime()
        }

        // Si las fechas son iguales, ordenar por hora
        return a.time.localeCompare(b.time)
      })
  }

  // Método para obtener partidos por jornada
  async getMatchesByMatchday(matchday: number): Promise<Match[]> {
    return matches.filter((match) => match.matchday === matchday)
  }

  // Método para obtener análisis de corners por jornada
  async getCornerAnalysisByMatchday(matchday: number): Promise<CornerAnalysis | null> {
    return cornerAnalysisRepository.getCornerAnalysisByMatchday(matchday)
  }
}

// Singleton para acceder al repositorio (patrón de diseño)
export const matchRepository = new MatchRepositoryImpl()
